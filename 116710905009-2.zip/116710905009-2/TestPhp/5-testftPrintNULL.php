<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Function which returns value</title>
</head>
<body>
    <?php
        function printMe($param = NULL) {
            print $param;
        }

        printMe("This is test");
        printMe();
        printMe("<br />This is Test");
        printMe();printMe();
    ?>
</body>
</html>