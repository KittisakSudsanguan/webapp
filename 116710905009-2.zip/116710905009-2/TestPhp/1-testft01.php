<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP FUNCTION</title>
</head>
<body>
    <h2>This is first for PHP</h2>
    <?PHP
    /* Defining a PHP Function */
    Function WriteMsg() {
        echo "You are really a nice person, Have a nice time!";
    }
    /* Calling the PHP Function */
    WriteMsg();
    ?>
</body>
</html>