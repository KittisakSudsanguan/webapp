<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>This is first for PHP which function calls</h2>
    <?PHP
    /* Defining a PHP Function */
    function sayHello() {
        echo "Hello com sci <br />";
    }
    $function_holder = "sayHello";
    $function_holder();
    sayHello();

    ?>
</body>
</html>